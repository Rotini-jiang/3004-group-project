package com.example.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import static com.example.intuo2.MainActivity.b;

public class ShowBudgetLibrary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_budget_library);
        TextView result = (TextView) findViewById(R.id.BLResult);
        String BudgetString = b.print();
        result.setText(BudgetString);
    }
}
