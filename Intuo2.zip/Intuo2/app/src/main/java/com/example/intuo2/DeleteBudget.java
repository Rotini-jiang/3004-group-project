package com.example.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import static com.example.intuo2.MainActivity.b;
import static com.example.intuo2.MainActivity.e;

public class DeleteBudget extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_budget);
        String[] a = b.getArrayOfName();
        Spinner deleteB = (Spinner) findViewById(R.id.DeleteBSpinner);
        Button DeleteBSubmit = (Button) findViewById(R.id.DeleteBSubmit);
        ArrayAdapter<String> BSpinner = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, a);
        BSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        deleteB.setAdapter(BSpinner);
        deleteB.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView result = (TextView) findViewById(R.id.DeleteBResult);
                result.setText(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        DeleteBSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView result2 = (TextView) findViewById(R.id.DeleteBResult);
                String Name = result2.getText().toString();
                b.deleteBudget(Name);
                Intent DeleteBOver = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(DeleteBOver);
            }
        });
    }
}
