package com.example.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    public static EventLibrary e = new EventLibrary();
    public static BudgetLibrary b = new BudgetLibrary();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageButton Home = (ImageButton)findViewById(R.id.img_main);
        ImageButton New = (ImageButton) findViewById(R.id.img_new);
        ImageButton Record = (ImageButton) findViewById(R.id.img_record);
        Home.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent HomeIntent = new Intent(getApplicationContext(),Home.class);
                startActivity(HomeIntent);
            }
        });
        New.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent NewIntent = new Intent(getApplicationContext(), New.class);
                startActivity(NewIntent);
            }
        });
        Record.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent RecordIntent = new Intent(getApplicationContext(),record.class);
                startActivity(RecordIntent);
            }
        });
    }



}
