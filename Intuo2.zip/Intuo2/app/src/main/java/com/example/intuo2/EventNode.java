package com.example.intuo2;

import java.io.Serializable;

public class EventNode implements Serializable {

    public Event data;
    public EventNode next;
    public EventNode previous;

    public EventNode(Event event) {
        this.data = event;
        previous = null;
        next = null;
    }
}