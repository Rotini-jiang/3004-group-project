package com.example.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import static com.example.intuo2.MainActivity.e;

public class ShowEventLibrary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_event_library);
        TextView result = (TextView) findViewById(R.id.ELResult);
        String EventString = e.print();
        result.setText(EventString);
    }
}
