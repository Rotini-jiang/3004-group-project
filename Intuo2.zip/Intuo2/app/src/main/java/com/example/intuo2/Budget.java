package com.example.intuo2;

import java.io.Serializable;

public class Budget implements Serializable {
    private String name;
    private float amount;
    private float usage;
    private Date startDate;
    private Date endDate;
    private int priority;

    public Budget(String n, float a, float u, Date s, Date e, int p){
        this.name = n;
        this.amount = a;
        this.usage = u;
        this.startDate = s;
        this. endDate = e;
        this.priority = p;
    }

    // Check if this priority is greater than parameter
    public boolean priorityCompare(int priority) {
        return this.priority >= priority;
    }

    public String getName(){
        return name;
    }

    public float getAmount(){
        return amount;
    }

    public float getUsage(){
        return usage;
    }

    public float restOfBudget(){
        return amount - usage;
    }

    public Date getStartDate(){ return startDate; }

    public Date getEndDate(){ return endDate;}

    public void setUsage(float u){usage += u; }

    public void thirtyPercentWarning(){
        if (usage >= amount * 0.7) {
            System.out.println("30% percent left");
        }
    }

    public void tenPercentWarning(){
        if (usage >= amount * 0.9) {
            System.out.println("10% percent left");
        }
    }

    public String print(){
        return "Budget is: "+ name + " , and the current balance is:  " + restOfBudget() + " ,the startDate is: " + startDate.print() + " , and the endDate is: " + endDate.print()+"\n\n";
    }
}