package com.example.intuo2;


public class BudgetLibrary {

    private BudgetList listB;
    public BudgetLibrary(){
        listB = new BudgetList();
    }
    public void addBudget(Budget b){
        listB.add(b);
    }
    public void deleteBudget(Budget b){
        listB.delete(b);
    }
    public String print(){
        return listB.print();
    }
}