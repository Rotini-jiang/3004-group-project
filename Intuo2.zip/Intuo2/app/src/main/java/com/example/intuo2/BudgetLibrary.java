package com.example.intuo2;


public class BudgetLibrary {

    private BudgetList listB;
    public BudgetLibrary(){
        listB = new BudgetList();
    }
    public void addBudget(Budget b){
        listB.add(b);
    }
    public void deleteBudget(String n){
        listB.delete(n);
    }
    public void update(Date d, float u){ listB.update(d,u);}
    public String[] getArrayOfName(){return listB.getArrayOfName();}
    public String print(){
        return listB.print();
    }
}