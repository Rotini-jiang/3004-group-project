package com.example.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import com.github.mikephil.charting.charts.BarChart;

import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;


import java.util.ArrayList;

public class chart extends AppCompatActivity {
    BudgetLibrary b = new BudgetLibrary();
    BarChart barChart;
    BudgetDataBaseHelper budgetDatabase = new BudgetDataBaseHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);
        InitializeBudgetLibrary(b);
        barChart = (BarChart) findViewById(R.id.barChart);

        ArrayList<String> XAxisLabel= new ArrayList<>();
        String[] Names = b.getArrayOfName();
        if(Names[0].equals("There is no Budget in your plan.")) {
            TextView result = (TextView) findViewById(R.id.chartText);
            String text = "There is no budget in you plan!";
            result.setText(text);
        }
        else{
            for (int i = 0; i < Names.length; i++) {
                XAxisLabel.add(Names[i]);
            }
            XAxis xAxis = barChart.getXAxis();
            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM_INSIDE);
            xAxis.setValueFormatter(new IndexAxisValueFormatter(XAxisLabel));
            xAxis.setGranularity(1f);
            xAxis.setGranularityEnabled(true);
            ArrayList<BarEntry> YAxis = new ArrayList<>();
            for (int i = 0; i < Names.length; i++) {
                YAxis.add(new BarEntry(i, b.getPercentage(Names[i])));
            }
            BarDataSet barDataSet = new BarDataSet(YAxis, "percentage");

            BarData data = new BarData(barDataSet);
            barChart.setData(data);
        }

    }

    public void InitializeBudgetLibrary(BudgetLibrary b){
        Cursor res = budgetDatabase.getAllData();
        if(res.getCount() ==0){
            return;
        }
        while(res.moveToNext()){
            String name = res.getString(0);
            float amount = Float.parseFloat(res.getString(1));
            float usage = Float.parseFloat(res.getString(2));
            int sDay = Integer.parseInt(res.getString(3));
            int sMonth = Integer.parseInt(res.getString(4));
            int sYear = Integer.parseInt(res.getString(5));
            int eDay = Integer.parseInt(res.getString(6));
            int eMonth = Integer.parseInt(res.getString(7));
            int eYear = Integer.parseInt(res.getString(8));
            int priority = Integer.parseInt(res.getString(9));
            Date sd = new Date(sDay,sMonth,sYear);
            Date ed = new Date(eDay, eMonth, eYear);
            Budget bd = new Budget(name,amount,usage,sd,ed,priority);
            b.addBudget(bd);
        }
    }

}
