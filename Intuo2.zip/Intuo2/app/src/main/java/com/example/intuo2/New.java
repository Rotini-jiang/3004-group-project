package com.example.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.Serializable;

import static com.example.intuo2.MainActivity.b;
import static com.example.intuo2.MainActivity.e;

public class New extends AppCompatActivity {

    MainActivity m = new MainActivity();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);

        Button btn1 = (Button)findViewById(R.id.btn1);
        Button btn2 = (Button)findViewById(R.id.btn2);
        Button test = (Button) findViewById(R.id.test);
        Button test2 = (Button)  findViewById(R.id.button);
        test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String string = e.print();
                TextView result = (TextView) findViewById(R.id.testText);
                result.setText(string);
            }
        });
        test2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String string = b.print();
                TextView result = (TextView) findViewById(R.id.BudgetResult);
                result.setText(string);
            }
        });
        btn1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent NewEventIntent = new Intent(getApplicationContext(), NewEvent.class);
                startActivity(NewEventIntent);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent NewBudgetIntent = new Intent(getApplicationContext(), NewBudget.class);
                startActivity(NewBudgetIntent);
            }
        });
    }

}
