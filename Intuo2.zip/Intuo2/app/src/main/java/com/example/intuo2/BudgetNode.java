package com.example.intuo2;

import java.io.Serializable;

public class BudgetNode implements Serializable {

    public Budget data;
    public BudgetNode next;
    public BudgetNode previous;

    public BudgetNode(Budget budget) {
        this.data = budget;
        previous = null;
        next = null;
    }
}