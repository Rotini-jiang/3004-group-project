package com.example.intuo2;

import java.io.Serializable;

public class Event implements Serializable {
    private Date date;
    private String name;
    private int priority;
    private String description;

    public Event(Date d, String n,String des,int p){
        this.date = d;
        this.name = n;
        this.description = des;
        this.priority = p;
    }

    // Check if this priority is greater than parameter
    public boolean priorityCompare(int priority) {
        return this.priority >= priority;
    }
    public int compareDate(Event e){
        return (this.date.dateCompare(e.date));
    }
    public int getPriority(){
        return this.priority;
    }
    public String getName(){
        return this.name;
    }
    public String getDescription(){ return this.description;}
    public Date getDate(){
        return this.date;
    }
    public String print(){
        return ("Event is on: "+ date.print() + " the name is: " + name+ " ,and the event is about: "+description+".\n\n");
    }
}