package com.example.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import static com.example.intuo2.MainActivity.b;

public class DailySpend extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_spend);
        Button RecordSubmit = (Button) findViewById(R.id.RecordSubmit);
        RecordSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText Day = (EditText) findViewById(R.id.RecordDay);
                EditText Month = (EditText) findViewById(R.id.RecordMonth);
                EditText Year = (EditText) findViewById(R.id.RecordYear);
                EditText DailyUsage = (EditText) findViewById(R.id.DailyUsage);
                int day = Integer.parseInt(Day.getText().toString());
                int month = Integer.parseInt(Month.getText().toString());
                int year = Integer.parseInt(Year.getText().toString());
                float usage = Float.parseFloat(DailyUsage.getText().toString());
                Date d = new Date(day,month,year);
                b.update(d,usage);
                Intent Submitted = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(Submitted);
            }
        });
    }
}
