package com.example.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class DailySpend extends AppCompatActivity {
    public BudgetLibrary b = new BudgetLibrary();
    BudgetDataBaseHelper budgetDatabase = new BudgetDataBaseHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_spend);
        InitializeBudgetLibrary(b);
        Button RecordSubmit = (Button) findViewById(R.id.RecordSubmit);
        RecordSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText Day = (EditText) findViewById(R.id.RecordDay);
                EditText Month = (EditText) findViewById(R.id.RecordMonth);
                EditText Year = (EditText) findViewById(R.id.RecordYear);
                EditText DailyUsage = (EditText) findViewById(R.id.DailyUsage);
                int day = Integer.parseInt(Day.getText().toString());
                int month = Integer.parseInt(Month.getText().toString());
                int year = Integer.parseInt(Year.getText().toString());
                float usage = Float.parseFloat(DailyUsage.getText().toString());
                Date d = new Date(day,month,year);
                String[] NameArray = b.getRangedArrayOfName(d);
                for(int i = 0; i < NameArray.length; i++){
                    if(NameArray[i] == null){
                        continue;
                    }
                    updateBudget(NameArray[i],usage);
                }
                b.update(d,usage);
                Intent Submitted = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(Submitted);
            }
        });
    }
    public void InitializeBudgetLibrary(BudgetLibrary b){
        Cursor res = budgetDatabase.getAllData();
        if(res.getCount() ==0){
            return;
        }
        while(res.moveToNext()){
            String name = res.getString(0);
            float amount = Float.parseFloat(res.getString(1));
            float usage = Float.parseFloat(res.getString(2));
            int sDay = Integer.parseInt(res.getString(3));
            int sMonth = Integer.parseInt(res.getString(4));
            int sYear = Integer.parseInt(res.getString(5));
            int eDay = Integer.parseInt(res.getString(6));
            int eMonth = Integer.parseInt(res.getString(7));
            int eYear = Integer.parseInt(res.getString(8));
            int priority = Integer.parseInt(res.getString(9));
            Date sd = new Date(sDay,sMonth,sYear);
            Date ed = new Date(eDay, eMonth, eYear);
            Budget bd = new Budget(name,amount,usage,sd,ed,priority);
            b.addBudget(bd);
        }
    }

    public void updateBudget(String n, float u){
        boolean result = budgetDatabase.updateData(n,u);
        if(result){
            Toast.makeText(DailySpend.this, "information updated",Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(DailySpend.this, "failed to update",Toast.LENGTH_LONG).show();
        }
    }
}
