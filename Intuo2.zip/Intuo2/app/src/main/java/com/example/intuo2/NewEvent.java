package com.example.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.Serializable;

import static com.example.intuo2.MainActivity.e;


public class NewEvent extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event);
        Button NewEventBtn = (Button) findViewById(R.id.NewEventBtn);
        NewEventBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                EditText Name = (EditText) findViewById(R.id.NameText);
                EditText Day = (EditText) findViewById(R.id.DayText);
                EditText Month = (EditText) findViewById(R.id.MonthText);
                EditText Year = (EditText) findViewById(R.id.YearText);
                EditText Description = (EditText) findViewById(R.id.DescriptionText);
                EditText Priority = (EditText) findViewById(R.id.PriorityText);

                TextView result = (TextView) findViewById(R.id.Test);

                String name = Name.getText().toString();
                int day = Integer.parseInt(Day.getText().toString());
                int month = Integer.parseInt(Month.getText().toString());
                int year = Integer.parseInt(Year.getText().toString());
                String description = Description.getText().toString();
                int priority = Integer.parseInt(Priority.getText().toString());

                Date eventDate = new Date(day, month,year);
                Event newEvent = new Event(eventDate,name,priority);
                String output = newEvent.print();

                result.setText(output + "");
                e.addEvent(newEvent);

                Intent EventLibrary = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(EventLibrary);


            }
        });
    }
}
