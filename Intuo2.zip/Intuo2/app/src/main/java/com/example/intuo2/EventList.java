package com.example.intuo2;

import java.io.Serializable;

public class EventList implements Serializable {
    private EventNode head;
    private EventNode tail;

    public EventList(){
        head = null;
        tail = null;
    }
    public void add(Event e){
        EventNode newNode = new EventNode(e);
        if(head == null){
            head = newNode;
            tail = newNode;
        }
        else{
            EventNode temp = head;
            while(true){
                if(newNode.data.compareDate(temp.data) == 1){
                    if(temp == head){
                        head.previous = newNode;
                        newNode.next = head;
                        head = newNode;
                        break;
                    }
                    else{
                        newNode.previous = temp.previous;
                        temp.previous.next = newNode;
                        temp.previous = newNode;
                        newNode.next = temp;
                        break;
                    }

                }
                else if(newNode.data.compareDate(temp.data) == 0){
                    if(newNode.data.priorityCompare(temp.data.getPriority())){
                        if(temp == head){
                            head.previous = newNode;
                            newNode.next = head;
                            head = newNode;
                            break;
                        }
                        else{
                            newNode.previous = temp.previous;
                            temp.previous.next = newNode;
                            temp.previous = newNode;
                            newNode.next = temp;
                            break;
                        }
                    }
                }
                if(temp == tail){
                    tail.next = newNode;
                    newNode.previous = tail;
                    tail = newNode;
                    newNode.next = null;
                    break;
                }
                temp = temp.next;
            }
        }
    }
    public void delete(String n){
        EventNode temp = head;
        if (head.data.getName().equals(n)){
            if(tail.data.getName().equals(n)){
                head = tail = null;
            }
            else{
                head = head.next;
                head.previous = null;
            }
        }
        else if(tail.data.getName().equals(n)){
            tail = tail.previous;
            tail.next = null;
        }
        else{
            while(true){
                if (temp.data.getName().equals(n)){
                    temp.previous.next = temp.next;
                    temp.next.previous = temp.previous;
                    break;
                }
                if(temp == tail){
                    System.out.println("Data is not in the list");
                    break;
                }
                else{
                    temp = temp.next;
                }
            }
        }
    }

    public int getListLength(){
        int length = 0;
        if(head == null){
            return 1;
        }
        EventNode temp = head;
        while(true){
            if(temp == null){
                return length;
            }
            length += 1;
            temp = temp.next;
        }
    }
    public String[] getArrayOfName(){
        String[] nameArray = new String[getListLength()];
        if(head == null){
            nameArray[0] = "There is no Event in your plan.";
            return nameArray;
        }
        EventNode temp = head;
        for(int i = 0; i<getListLength(); i++){
            nameArray[i] = temp.data.getName();
            temp = temp.next;
        }
        return nameArray;
    }

    public void update(Date d){
        if (head == null){
            return;
        }
        EventNode temp = head;
        while(true){
            if(temp == null){
                break;
            }
            else if(temp.data.getDate().dateCompare(d) >0){
                delete(temp.data.getName());
            }
            temp = temp.next;

        }
    }

    public String print(){
        String s = "";
        EventNode temp = head;
        while(true){
            if(temp == null){
                break;
            }
            s +=temp.data.print();
            temp = temp.next;
        }
        return s;
    }
}
