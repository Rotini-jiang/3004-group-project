package com.example.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import static com.example.intuo2.MainActivity.b;

public class NewBudget extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_budget);
        Button NewBudgetBtn = (Button) findViewById(R.id.NewBudgetButton);
        NewBudgetBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                EditText Name = (EditText) findViewById(R.id.editTextN);
                EditText Amount = (EditText) findViewById(R.id.amount);
                EditText Priority = (EditText) findViewById(R.id.priorityB);
                EditText DayS = (EditText) findViewById(R.id.dayS);
                EditText MonthS = (EditText) findViewById(R.id.monthS);
                EditText YearS = (EditText) findViewById(R.id.yearS);
                EditText DayE = (EditText) findViewById(R.id.dayE);
                EditText MonthE = (EditText) findViewById(R.id.monthE);
                EditText YearE = (EditText) findViewById(R.id.yearE);

                float amount = Float.parseFloat(Amount.getText().toString());
                int dayS = Integer.parseInt(DayS.getText().toString());
                int monthS = Integer.parseInt(MonthS.getText().toString());
                int yearS = Integer.parseInt(YearS.getText().toString());
                int dayE = Integer.parseInt(DayE.getText().toString());
                int monthE = Integer.parseInt(MonthE.getText().toString());
                int yearE = Integer.parseInt(YearE.getText().toString());
                int priority = Integer.parseInt(Priority.getText().toString());
                String name = Name.getText().toString();
                Date startDate = new Date(dayS, monthS,yearS);
                Date endDate = new Date(dayE, monthE,yearE);
                Budget newBudget = new Budget(name, amount, startDate, endDate, priority);
                b.addBudget(newBudget);

                Intent BudgetLibrary = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(BudgetLibrary);

            }
        });
    }
}
