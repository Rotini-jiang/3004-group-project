package com.example.intuo2;

public class EventLibrary{
    private EventList listE;
    public EventLibrary(){
        listE = new EventList();
    }
    public void addEvent(Event e){
        listE.add(e);
    }
    public void deleteEvent(Event e){
        listE.delete(e);
    }
    public String print(){
       return listE.print();
    }
}
