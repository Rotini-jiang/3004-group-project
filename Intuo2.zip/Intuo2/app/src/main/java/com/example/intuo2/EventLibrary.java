package com.example.intuo2;

public class EventLibrary{
    private EventList listE;
    public EventLibrary(){
        listE = new EventList();
    }
    public void addEvent(Event e){
        listE.add(e);
    }
    public void deleteEvent(String n){
        listE.delete(n);
    }
    public String[] getArrayOfName(){return listE.getArrayOfName();}
    public String print(){
       return listE.print();
    }
}
