package com.example.intuo2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BudgetDataBaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "BUDGET";
    private static final String TABLE_NAME = "Budget_Table";
    private static final String COL1 = "Name";
    private static final String COL2 = "Amount";
    private static final String COL3 = "Usage";
    private static final String COL4 = "Sday";
    private static final String COL5 = "SMonth";
    private static final String COL6 = "SYear";
    private static final String COL7 = "EDay";
    private static final String COL8 = "EMonth";
    private static final String COL9 = "EYear";
    private static final String COL10 = "Priority";

    public BudgetDataBaseHelper(Context context){
        super(context, DB_NAME, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db){
        String create_table = "CREATE TABLE " + TABLE_NAME +"(" + COL1 +" TEXT," + COL2 + " FLOAT," + COL3 + " FLOAT," + COL4 + " INTEGER," + COL5 +" INTEGER," + COL6 + " INTEGER, "+ COL7 + " INTEGER," + COL8 + " INTEGER," + COL9 + " INTEGER," + COL10 + " INTEGER);";
        db.execSQL(create_table);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        String drop_table = "DROP TABLE IF EXISTS " + TABLE_NAME;
        db.execSQL(drop_table);
        onCreate(db);
    }
    public boolean insertData(String name, float amount, float usage, int sDay, int sMonth, int sYear, int eDay, int eMonth, int eYear, int priority){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, name);
        contentValues.put(COL2, amount);
        contentValues.put(COL3, usage);
        contentValues.put(COL4, sDay);
        contentValues.put(COL5, sMonth);
        contentValues.put(COL6, sYear);
        contentValues.put(COL7, eDay);
        contentValues.put(COL8, eMonth);
        contentValues.put(COL9, eYear);
        contentValues.put(COL10, priority);
        long result = db.insert(TABLE_NAME, null, contentValues);
        if(result == -1){
            return false;
        }
        else{
            return true;
        }
    }
    public Cursor getAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM "+ TABLE_NAME;
        Cursor res = db.rawQuery(query, null);
        return res;
    }

    public boolean updateData(String Name, float usage){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL3, usage);
        db.update(TABLE_NAME,contentValues,"Name = ?", new String[] {Name});
        return true;
    }

    public int DeleteData(String Name){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "Name = ?", new String[] {Name});

    }

}
