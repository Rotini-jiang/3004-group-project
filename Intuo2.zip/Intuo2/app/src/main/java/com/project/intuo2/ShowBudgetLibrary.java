package com.project.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;


public class ShowBudgetLibrary extends AppCompatActivity {
    BudgetDataBaseHelper budgetDatabase = new BudgetDataBaseHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_budget_library);
        BudgetLibrary b = new BudgetLibrary();
        InitializeBudgetLibrary(b);
        TextView result = (TextView) findViewById(R.id.BLResult);
        String BudgetString = b.print();
        result.setText(BudgetString);
    }

    public void InitializeBudgetLibrary(BudgetLibrary b){
        Cursor res = budgetDatabase.getAllData();
        if(res.getCount() ==0){
            return;
        }
        while(res.moveToNext()){
            String name = res.getString(0);
            float amount = Float.parseFloat(res.getString(1));
            float usage = Float.parseFloat(res.getString(2));
            int sDay = Integer.parseInt(res.getString(3));
            int sMonth = Integer.parseInt(res.getString(4));
            int sYear = Integer.parseInt(res.getString(5));
            int eDay = Integer.parseInt(res.getString(6));
            int eMonth = Integer.parseInt(res.getString(7));
            int eYear = Integer.parseInt(res.getString(8));
            int priority = Integer.parseInt(res.getString(9));
            Date sd = new Date(sDay,sMonth,sYear);
            Date ed = new Date(eDay, eMonth, eYear);
            Budget bd = new Budget(name,amount,usage,sd,ed,priority);
            b.addBudget(bd);
        }
    }
}
