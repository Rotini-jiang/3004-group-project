package com.project.intuo2;


public class BudgetLibrary {

    private BudgetList listB;
    public BudgetLibrary(){
        listB = new BudgetList();
    }
    public void addBudget(Budget b){
        listB.add(b);
    }
    public void deleteBudget(String n){
        listB.delete(n);
    }
    public void update(Date d, float u){ listB.update(d,u);}
    public String[] getArrayOfName(){return listB.getArrayOfName();}
    public String[] getRangedArrayOfName(Date d){return listB.getRangedArrayOfName(d);}
    public int getPercentage(String n){ return listB.getPercentage(n);}
    public String print(){
        return listB.print();
    }
    public float setUsage(String name, float u){return listB.setUsage(name,u);}
}