package com.project.intuo2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "SUPERDATABASE";
    private static final String TABLE_NAME = "Event_Table";
    private static final String COL1 = "Day";
    private static final String COL2 = "Month";
    private static final String COL3 = "Year";
    private static final String COL4 = "Name";
    private static final String COL5 = "Priority";
    private static final String COL6 = "Description";

    public DatabaseHelper(Context context){
        super(context, DB_NAME, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db){
        String create_table = "CREATE TABLE " + TABLE_NAME +"(" + COL1 +" INTEGER," + COL2 + " INTEGER," + COL3 + " INTEGER," + COL4 + " TEXT," + COL5 +" INTEGER," + COL6 + " TEXT);";
        db.execSQL(create_table);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        String drop_table = "DROP TABLE IF EXISTS " + TABLE_NAME;
        db.execSQL(drop_table);
        onCreate(db);
    }
    public boolean insertData(int day, int month, int year, String name, int priority, String description){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, day);
        contentValues.put(COL2, month);
        contentValues.put(COL3, year);
        contentValues.put(COL4, name);
        contentValues.put(COL5, priority);
        contentValues.put(COL6, description);
        long result = db.insert(TABLE_NAME, null, contentValues);
        if(result == -1){
            return false;
        }
        else{
            return true;
        }
    }
    public Cursor getAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM "+ TABLE_NAME;
        Cursor res = db.rawQuery(query, null);
        return res;
    }

    public int DeleteData(String Name){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "Name = ?", new String[] {Name});

    }
}
