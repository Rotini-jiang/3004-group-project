package com.project.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;


public class NewEvent extends AppCompatActivity {

    DatabaseHelper EventDatabaseHelper = new DatabaseHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event);
        Button NewEventBtn = (Button) findViewById(R.id.NewEventBtn);
        createNotificationChannel();
        NewEventBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                EditText Name = (EditText) findViewById(R.id.NameText);
                EditText Day = (EditText) findViewById(R.id.DayText);
                EditText Month = (EditText) findViewById(R.id.MonthText);
                EditText Year = (EditText) findViewById(R.id.YearText);
                EditText Description = (EditText) findViewById(R.id.DescriptionText);
                EditText Priority = (EditText) findViewById(R.id.PriorityText);
                String name = Name.getText().toString();
                int day = Integer.parseInt(Day.getText().toString());
                int month = Integer.parseInt(Month.getText().toString());
                int year = Integer.parseInt(Year.getText().toString());
                String description = Description.getText().toString();
                int priority = Integer.parseInt(Priority.getText().toString());
                addData(day,month,year,name,priority,description);


                AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                Calendar calendar = Calendar.getInstance();
                calendar.set(year,month -1,day,12,30,0);
                Intent intent = new Intent(NewEvent.this, EventAlarm.class);
                PendingIntent broadcast = PendingIntent.getBroadcast(NewEvent.this, 0,intent,0);
                alarmManager.setExact(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),broadcast);

                Intent EventLibrary = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(EventLibrary);


            }
        });
    }

    public void addData(int day, int month, int year, String name, int priority, String description){
        boolean insertData =EventDatabaseHelper.insertData(day,month,year,name,priority,description);
        if(insertData){
            Toast.makeText(NewEvent.this, "Event Saved",Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(NewEvent.this, "Please enter valid information",Toast.LENGTH_LONG).show();
        }
    }

    public void createNotificationChannel(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "HongxiNotificationChannel";
            NotificationChannel channel = new NotificationChannel("notification", name, NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Channel made by Hongxi Zhang");
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

    }
}
