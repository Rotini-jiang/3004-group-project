package com.project.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;



public class ShowEventLibrary extends AppCompatActivity {
    public EventLibrary e = new EventLibrary();
    DatabaseHelper EventDatabaseHelper = new DatabaseHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_event_library);
        InitializeEventLibrary(e);
        TextView result = (TextView) findViewById(R.id.ELResult);
        String EventString = e.print();
        result.setText(EventString);
    }

    public void InitializeEventLibrary(EventLibrary e){
        Cursor res = EventDatabaseHelper.getAllData();
        if(res.getCount() ==0){
            return;
        }
        while(res.moveToNext()){
            int day = Integer.parseInt(res.getString(0));
            int month = Integer.parseInt(res.getString(1));
            int year = Integer.parseInt(res.getString(2));
            String name = res.getString(3);
            int priority = Integer.parseInt(res.getString(4));
            String description = res.getString(5);
            Date d = new Date(day,month,year);
            Event ev = new Event(d, name,description,priority);
            e.addEvent(ev);
        }
    }
}
