package com.project.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class record extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);
        Button Record = (Button) findViewById(R.id.DailySpend);
        Button DeleteE = (Button) findViewById(R.id.DeleteE);
        Button DeleteB = (Button) findViewById(R.id.deleteB);
        Record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent DailySpend = new Intent(getApplicationContext(), DailySpend.class);
                startActivity(DailySpend);
            }
        });
        DeleteE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent DeleteEvent = new Intent(getApplicationContext(), DeleteEvent.class);
                startActivity(DeleteEvent);
            }
        });
        DeleteB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent DeleteBudget = new Intent(getApplicationContext(), DeleteBudget.class);
                startActivity(DeleteBudget);
            }
        });
    }
}
