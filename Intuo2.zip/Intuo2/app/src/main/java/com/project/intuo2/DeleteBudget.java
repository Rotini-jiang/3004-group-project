package com.project.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class DeleteBudget extends AppCompatActivity {
    public BudgetLibrary b = new BudgetLibrary();
    BudgetDataBaseHelper budgetDatabase = new BudgetDataBaseHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_budget);

        InitializeBudgetLibrary(b);
        String[] a = b.getArrayOfName();
        Spinner deleteB = (Spinner) findViewById(R.id.DeleteBSpinner);
        Button DeleteBSubmit = (Button) findViewById(R.id.DeleteBSubmit);
        ArrayAdapter<String> BSpinner = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, a);
        BSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        deleteB.setAdapter(BSpinner);
        deleteB.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView result = (TextView) findViewById(R.id.DeleteBResult);
                result.setText(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        DeleteBSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView result2 = (TextView) findViewById(R.id.DeleteBResult);
                String Name = result2.getText().toString();
                deleteBudget(Name);
                b.deleteBudget(Name);
                Intent DeleteBOver = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(DeleteBOver);
            }
        });
    }
    public void InitializeBudgetLibrary(BudgetLibrary b){
        Cursor res = budgetDatabase.getAllData();
        if(res.getCount() ==0){
            return;
        }
        while(res.moveToNext()){
            String name = res.getString(0);
            float amount = Float.parseFloat(res.getString(1));
            float usage = Float.parseFloat(res.getString(2));
            int sDay = Integer.parseInt(res.getString(3));
            int sMonth = Integer.parseInt(res.getString(4));
            int sYear = Integer.parseInt(res.getString(5));
            int eDay = Integer.parseInt(res.getString(6));
            int eMonth = Integer.parseInt(res.getString(7));
            int eYear = Integer.parseInt(res.getString(8));
            int priority = Integer.parseInt(res.getString(9));
            Date sd = new Date(sDay,sMonth,sYear);
            Date ed = new Date(eDay, eMonth, eYear);
            Budget bd = new Budget(name,amount,usage,sd,ed,priority);
            b.addBudget(bd);
        }
    }
    public void deleteBudget(String name){
        int result = budgetDatabase.DeleteData(name);
        if(result >0){
            Toast.makeText(DeleteBudget.this, "Budget deleted",Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(DeleteBudget.this, "failed to delete",Toast.LENGTH_LONG).show();
        }
    }

}
