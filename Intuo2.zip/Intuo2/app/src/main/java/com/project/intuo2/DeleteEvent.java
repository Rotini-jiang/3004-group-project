package com.project.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class DeleteEvent extends AppCompatActivity {
    public EventLibrary e = new EventLibrary();
    DatabaseHelper EventDatabaseHelper = new DatabaseHelper(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_event);
        InitializeEventLibrary(e);
        String[] a = e.getArrayOfName();
        Spinner deleteE = (Spinner) findViewById(R.id.deleteESpinner);
        Button DeleteESubmit = (Button) findViewById(R.id.DeleteESubmit);
        ArrayAdapter<String> ESpinner = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, a);
        ESpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        deleteE.setAdapter(ESpinner);
        deleteE.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView result = (TextView) findViewById(R.id.SelectEResult);
                result.setText(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        DeleteESubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView result2 = (TextView) findViewById(R.id.SelectEResult);
                String Name = result2.getText().toString();
                deleteEvent(Name);
                e.deleteEvent(Name);
                Intent DeleteEOver = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(DeleteEOver);
            }
        });
    }
    public void InitializeEventLibrary(EventLibrary e){
        Cursor res = EventDatabaseHelper.getAllData();
        if(res.getCount() ==0){
            return;
        }
        while(res.moveToNext()){
            int day = Integer.parseInt(res.getString(0));
            int month = Integer.parseInt(res.getString(1));
            int year = Integer.parseInt(res.getString(2));
            String name = res.getString(3);
            int priority = Integer.parseInt(res.getString(4));
            String description = res.getString(5);
            Date d = new Date(day,month,year);
            Event ev = new Event(d, name,description,priority);
            e.addEvent(ev);
        }
    }

    public void deleteEvent(String name){
        int result = EventDatabaseHelper.DeleteData(name);
        if(result >0){
            Toast.makeText(DeleteEvent.this, "Event deleted",Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(DeleteEvent.this, "failed to delete",Toast.LENGTH_LONG).show();
        }
    }
}
