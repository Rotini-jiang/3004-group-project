package com.project.intuo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Button showEvent = (Button)findViewById(R.id.EventLibrary);
        Button showBudget = (Button)findViewById(R.id.BudgetLibrary);
        showEvent.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent EventLibrary = new Intent(getApplicationContext(),ShowEventLibrary.class);
                startActivity(EventLibrary);
            }
        });
        showBudget.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent BudgetLibrary = new Intent(getApplicationContext(),ShowBudgetLibrary.class);
                startActivity(BudgetLibrary);
            }
        });
    }
}
