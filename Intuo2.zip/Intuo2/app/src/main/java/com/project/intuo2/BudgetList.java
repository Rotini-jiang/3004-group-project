package com.project.intuo2;

import java.io.Serializable;
import java.lang.reflect.Array;

public class BudgetList implements Serializable {
    private BudgetNode head;
    private BudgetNode tail;

    public BudgetList() {
        head = null;
        tail = null;
    }
    public void add(Budget b){
        BudgetNode newNode = new BudgetNode(b);
        if(head == null){
            tail = newNode;
            head = newNode;
        }
        else{
            tail.next = newNode;
            newNode.previous = tail;
            tail = newNode;
            newNode.next = null;
        }
    }

    public void delete(String n){
        BudgetNode temp = head;
        if (head.data.getName().equals(n) ){
            if(tail.data.getName().equals(n)){
                head = tail = null;
            }
            else{
                head = head.next;
                head.previous = null;
            }
        }
        else if(tail.data.getName().equals(n)){
            tail = tail.previous;
            tail.next = null;
        }
        else{
            while(true){
                if (temp.data.getName().equals(n)){
                    temp.previous.next = temp.next;
                    temp.next.previous = temp.previous;
                    break;
                }
                if(temp == tail){
                    System.out.println("Data is not in the list");
                    break;
                }
                else{
                    temp = temp.next;
                }
            }
        }
    }

    public void update(Date d, float u){
        if (head == null){
            return;
        }
        BudgetNode temp = head;
        while(true){
            if(temp == null){
                break;
            }
            if(temp.data.getStartDate().dateCompare(d) >=0 && temp.data.getEndDate().dateCompare(d) <= 0){
                temp.data.setUsage(u);
            }
            else if(temp.data.getEndDate().dateCompare(d) >0){
                delete(temp.data.getName());
            }
            temp = temp.next;

        }
    }
    public int getListLength(){
        int length = 0;
        if(head == null){
            return 1;
        }
        BudgetNode temp = head;
        while(true){
            if(temp == null){
                return length;
            }
            length += 1;
            temp = temp.next;
        }
    }
    public String[] getArrayOfName(){
        String[] nameArray = new String[getListLength()];
        if(head == null){
            nameArray[0] = "There is no Budget in your plan.";
            return nameArray;
        }
        BudgetNode temp = head;
        for(int i = 0; i<getListLength(); i++){
            nameArray[i] = temp.data.getName();
            temp = temp.next;
        }
        return nameArray;
    }

    public String[] getRangedArrayOfName(Date d){
        String[] nameArray = new String[getListLength()];
        if(head == null){
            nameArray[0] = "There is no Budget in your plan.";
            return nameArray;
        }
        BudgetNode temp = head;

        for(int i = 0; i<getListLength(); i++){
            if(temp.data.getEndDate().dateCompare(d) == 1 || temp.data.getStartDate().dateCompare(d) == -1 ) {
                temp = temp.next;
                continue;
            }
            nameArray[i] = temp.data.getName();
            temp = temp.next;
        }
        return nameArray;
    }

    public float setUsage(String name, float u){
        BudgetNode temp = head;
        while(true) {
            if (temp.data.getName().equals(name)) {
                temp.data.setUsage(u);
                float usage = temp.data.getUsage();
                return usage;
            }
            temp = temp.next;
        }
    }


    public int getPercentage(String name){
        BudgetNode temp = head;
        while(true) {
            if (temp.data.getName().equals(name)) {
                return temp.data.getPercentage();
            }
            temp = temp.next;
        }
    }

    public String print(){
        String s = "";
        BudgetNode temp = head;
        while(true){
            if(temp == null){
                break;
            }
            s+=temp.data.print();
            temp = temp.next;
        }
        return s;
    }
}
