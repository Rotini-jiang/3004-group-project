package com.example.intuo2;

import android.app.Activity;
import android.os.Bundle;
//import android.support.annotation.Nullable;


public class ForgotInfo_activity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_info_activity);
    }
}